import math

def cosine_similarity(vector1, vector2):
    dot_product = sum([v1 * v2 for v1, v2 in zip(vector1, vector2)])
    magnitude1 = math.sqrt(sum([v1**2 for v1 in vector1]))
    magnitude2 = math.sqrt(sum([v2**2 for v2 in vector2]))
    return dot_product / (magnitude1 * magnitude2)
